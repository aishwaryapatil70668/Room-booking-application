package com.cg.RoomBookingAppSpringBoot.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.RoomBookingAppSpringBoot.dto.Customer;

public interface ICustomerDao extends JpaRepository<Customer, Integer> {
public Customer findByid(int id);
}
