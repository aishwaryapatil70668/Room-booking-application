package com.cg.RoomBookingAppSpringBoot.dto;

import java.math.BigDecimal;



/*
 * This is bean class for room it includes id,number,price,type
 * Constructor,getter setter ,toString is defined
 *  Last Modified 14/05/2019  
 *  @Author: Aishwarya Patil
 * */  


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Room {

	@Id
	@Column(name="roomid")
	private Integer id;
	private Integer number;
	private String type;
	private BigDecimal price;
	
	

	public Room() {
		
	}
	
	public Room(Integer id, Integer number, String type, BigDecimal price) {
		super();
		this.id = id;
		this.number = number;
		this.type = type;
		this.price = price;
	
	}

	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}



	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getNumber() {
		return number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}



	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	





	
	
}