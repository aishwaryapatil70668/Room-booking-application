package com.cg.RoomBookingAppSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.cg.RoomBookingAppSpringBoot")
public class RoomBookingAppSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoomBookingAppSpringBootApplication.class, args);
	//	System.out.println("hiee");
	}

}
