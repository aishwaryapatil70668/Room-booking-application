package com.cg.RoomBookingAppSpringBoot.exception;

public class CustomerIdException extends RuntimeException {

	public CustomerIdException()
	{
		
	}
	public CustomerIdException(String msgs)
	{
		super(msgs);
	}
}
