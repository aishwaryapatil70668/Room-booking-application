package com.cg.RoomBookingAppSpringBoot.service;

import java.util.List;

import com.cg.RoomBookingAppSpringBoot.dto.Booking;
import com.cg.RoomBookingAppSpringBoot.dto.Room;

public interface IBookingService {
	public Booking addBooking(Booking booking);
	public Booking searchByBookId(int id);
	List<Room> searchByRoomType(String type);
}
