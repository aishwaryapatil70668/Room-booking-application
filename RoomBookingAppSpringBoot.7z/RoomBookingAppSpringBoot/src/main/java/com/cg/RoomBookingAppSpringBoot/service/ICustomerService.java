package com.cg.RoomBookingAppSpringBoot.service;

import java.util.List;

import com.cg.RoomBookingAppSpringBoot.dto.Booking;
import com.cg.RoomBookingAppSpringBoot.dto.Customer;

public interface ICustomerService {
	public Customer addCustomer(Customer customer);
	public Customer searchByBookId(int id);
}
