package com.cg.RoomBookingAppSpringBoot.dao;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.RoomBookingAppSpringBoot.dto.Booking;
import com.cg.RoomBookingAppSpringBoot.dto.Room;

public interface IBookingDao extends JpaRepository<Booking, Integer>  {

	@Query("FROM Room r where r.type = ?1")
	public  List<Room> findBytype(String type);
	public Booking findByid(int id);
}
