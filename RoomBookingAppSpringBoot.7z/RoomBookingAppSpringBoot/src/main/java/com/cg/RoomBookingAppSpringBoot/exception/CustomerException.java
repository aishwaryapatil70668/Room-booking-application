package com.cg.RoomBookingAppSpringBoot.exception;

public class CustomerException extends RuntimeException {

	public CustomerException()
	{
		
	}
	public CustomerException(String msgs)
	{
		super(msgs);
	}
	
}
