package com.cg.RoomBookingAppSpringBoot.service;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.RoomBookingAppSpringBoot.dao.ICustomerDao;
import com.cg.RoomBookingAppSpringBoot.dto.Customer;
import com.cg.RoomBookingAppSpringBoot.exception.CustomerException;
import com.cg.RoomBookingAppSpringBoot.exception.Exceptions;

/*
 * @Author Aishwarya patil
 * @Last Modified on 25-05-2019
 * The Following  service class is for Business logic
 */ 
@Service("customerService")
@Transactional
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	ICustomerDao customerDao;
	static final Logger logger = Logger.getLogger(CustomerServiceImpl.class); 	
	/** 
	 * This method is used to save the customer. 
	 * @Author Aishwarya patil
	 * @param customer this parameter is used to save the customers by given customer
	 * @return Customer
	 * @Last Modified on 25-05-2019
	 * @throws CustomerException
	 * */ 
	public Customer addCustomer(Customer customer) {
		PropertyConfigurator.configure("D:\\JavaProjectadvance\\RoomBookingAppSpringBoot\\src\\main\\java\\resources\\log4j.properties"); 

		Customer cust=customerDao.findByid(customer.getId());

		if(cust==null)
			customerDao.save(customer);
		else
		{	
			logger.warn("customer id already exist");
			throw new CustomerException("id already exist");
		}
		logger.info("customer added successful");
		return customer;
	}

	/** 
	 * This method is used to search the customer.
	 * @Author Aishwarya patil
	 * @param id this parameter is used to find the customer by given id
	 * @return Customer
	 * @throws CustomerException
	 * @Last Modified on 25-05-2019
	 * */ 
	public Customer searchByBookId(int id) {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("D:\\JavaProjectadvance\\RoomBookingAppSpringBoot\\src\\main\\java\\resources\\log4j.properties"); 

		Customer cust=customerDao.findByid(id);
		if(cust==null) {
			logger.warn("customer id not found ");
			throw new Exceptions("Customer id not found Exception");
		}
		logger.info("customer added successful");
		return cust;
	}
}
