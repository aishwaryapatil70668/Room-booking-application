package com.cg.RoomBookingAppSpringBoot.service;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.RoomBookingAppSpringBoot.dao.IBookingDao;
import com.cg.RoomBookingAppSpringBoot.dto.Booking;
import com.cg.RoomBookingAppSpringBoot.dto.Room;
import com.cg.RoomBookingAppSpringBoot.exception.CustomerException;
import com.cg.RoomBookingAppSpringBoot.exception.Exceptions;

/*
 * @Author Aishwarya patil
 * @Last Modified on 10-05-2019
 * The Following service class is for Business logic
 */ 

@Service("bookingService")
@Transactional
public class BookingServiceImpl implements IBookingService {


	@Autowired
	IBookingDao bookingDao;	
	static int roomid=1; 
	static final Logger logger = Logger.getLogger(BookingServiceImpl.class); 	

	/** 
	 * This method is used to save the booking. 
	 * @Author Aishwarya patil
	 * @param booking this parameter is used to save the booking by given booking
	 * @return Booking
	 * @Last Modified on 25-05-2019
	 * */ 
	public Booking addBooking(Booking booking) {
		PropertyConfigurator.configure("D:\\JavaProjectadvance\\RoomBookingAppSpringBoot\\src\\main\\java\\resources\\log4j.properties"); 


		for(Room room:booking.getRooms())
		{
			room.setId(roomid);
			roomid++;
		}


		logger.info("Booking added successful");
		return bookingDao.save(booking);
	}

	/** 
	 * This method is used to search the booking . 
	 * @Author Aishwarya patil
	 * @param id this parameter is used to find the booking by given id
	 * @return Booking
	 * @throws Exceptions
	 * @Last Modified on 25-05-2019
	 * */ 
	public Booking searchByBookId(int id) {
		PropertyConfigurator.configure("D:\\JavaProjectadvance\\RoomBookingAppSpringBoot\\src\\main\\java\\resources\\log4j.properties"); 

		Booking book=bookingDao.findByid(id);
		if(book==null)
		{

			logger.warn("Booking id not found");
			throw new Exceptions("Booking id not found ");
		}	
		logger.info("searching booking details by id");
		return book;
	}


	/** 
	 * This method is used to search the roomtype.
	 * @Author Aishwarya patil 
	 * @param type this parameter is used to find the room type by given type
	 * @return Room
	 * @Last Modified on 25-05-2019
	 * @throws Exceptions
	 * */ 
	public List<Room> searchByRoomType(String type) {
		PropertyConfigurator.configure("D:\\JavaProjectadvance\\RoomBookingAppSpringBoot\\src\\main\\java\\resources\\log4j.properties"); 

		List<Room> room=bookingDao.findBytype(type);

		if(room.isEmpty())
		{   
			logger.warn("this type of room not found ");
			throw new Exceptions("this type of room not found ");
		}
		logger.info("searching room by type");
		return room;	
	}



}
