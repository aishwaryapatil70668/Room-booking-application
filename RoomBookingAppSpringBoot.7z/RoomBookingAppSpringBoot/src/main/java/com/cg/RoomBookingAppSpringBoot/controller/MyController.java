package com.cg.RoomBookingAppSpringBoot.controller;
import java.sql.Timestamp;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cg.RoomBookingAppSpringBoot.dto.Booking;
import com.cg.RoomBookingAppSpringBoot.dto.Customer;
import com.cg.RoomBookingAppSpringBoot.dto.Room;
import com.cg.RoomBookingAppSpringBoot.exception.CustomerException;
import com.cg.RoomBookingAppSpringBoot.exception.Exceptions;
import com.cg.RoomBookingAppSpringBoot.service.IBookingService;
import com.cg.RoomBookingAppSpringBoot.service.ICustomerService;

@RestController
@RequestMapping("/booking")
public class MyController {

	@Autowired
	ICustomerService custservice;

	@Autowired
	IBookingService bookservice; 


	/* 
	 * This method map to http://localhost:9090//booking/addCustomer
	 * @param @ModelAttribute customer
	 * @return customer
	 * @Last Modified on 25-05-2019
	 * 
	 * * */ 
	@RequestMapping(value="/addCustomer", method=RequestMethod.POST)
	public ResponseEntity<Customer> addAll (@ModelAttribute Customer customer)
	{
		Customer cust=custservice.addCustomer(customer);
		return new ResponseEntity<Customer>(cust,HttpStatus.OK);

	}	

	/* 
	 * This method map to http://localhost:9090//booking/addBooking
	 * @param @ModelAttribute  booking
	 * @return booking
	 * @Last Modified on 25-05-2019
	 * 
	 * * */ 

	@RequestMapping(value="/addBooking", method=RequestMethod.POST)
	public ResponseEntity<Booking> addAll (@ModelAttribute Booking booking)
	{

		booking.setDate(new Timestamp(System.currentTimeMillis()));
		Customer cust=custservice.searchByBookId(booking.getCustomer().getId());

		booking.setCustomer(cust);

		Booking book=bookservice.addBooking(booking);

		return new ResponseEntity<Booking>(book,HttpStatus.OK);

	}


	/* 
	 * This method map to http://localhost:9090//booking/searchid
	 * @param @RequestParam id  
	 * @return booking
	 * @Last Modified on 25-05-2019
	 * * */ 

	@RequestMapping(value="/searchid", method=RequestMethod.Get)
	public ResponseEntity<Booking> searchbyid(@RequestParam("id") int id)
	{
		Booking book=bookservice.searchByBookId(id);

	/*	if(book==null)
		{
			return new ResponseEntity("Booking details not found ",HttpStatus.NOT_FOUND);
		}*/
		return new ResponseEntity<Booking>(book,HttpStatus.OK);

	}


	/* 
	 * This method map to http://localhost:9090//booking/searchtype
	 * @param @ModelAttribute @RequestParam type
	 * @return rooms
	 * @Last Modified on 25-05-2019
	 * * */ 
	@RequestMapping(value="/searchtype", method=RequestMethod.POST)
	public ResponseEntity<List<Room>> search(@RequestParam("type") String type)

	{	

		List<Room> mylist=bookservice.searchByRoomType(type);
		/*if(mylist.isEmpty())
		{
			return new ResponseEntity<List<Room>>("this type of room not found ",HttpStatus.NOT_FOUND);

		}
		*/
		
		return new ResponseEntity<List<Room>> (mylist,HttpStatus.OK);

	}
	
	
	/*
	@ExceptionHandler method
	 * Handles @CustomerException
	 */ 
	@ExceptionHandler({CustomerException.class})
	public ResponseEntity<String> handlePlayerExceptionS(CustomerException e) {

		return new ResponseEntity<String>(e.getMessage(),HttpStatus.NOT_FOUND);
	}  

	
	
	
	
	
	
	@ExceptionHandler({Exceptions.class})
	public ResponseEntity<String> handlePlayerException(Exceptions e) {
		return new ResponseEntity<String>(e.getMessage(),HttpStatus.NOT_FOUND);

	}  










}