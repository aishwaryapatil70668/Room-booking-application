package com.cg.booking.dao;

import com.cg.booking.dto.Customer;

public interface ICustomerDao {
public Customer save(Customer customer);
public Customer findByCustomerId(int id);
}
