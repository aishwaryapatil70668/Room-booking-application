package com.cg.booking.service;

import java.util.List;

import com.cg.booking.dao.BookingDaoImpl;
import com.cg.booking.dao.IBookingDao;
import com.cg.booking.dto.Booking;
import com.cg.booking.dto.Room;
import com.cg.booking.exception.Exceptions;


public class BookingServiceImpl implements IBookingService {
	IBookingDao bookingDao;	
	public BookingServiceImpl() {
		bookingDao =new BookingDaoImpl();
	}
	
	
	public Booking addBooking(Booking booking) {
		
		
		
		return bookingDao.save(booking);
	}
	
	// This method is used to find Booking details of customer
	// id is the parameter to search book id method 
	public Booking searchByBookId(int id) {
		
	
		if(bookingDao.findByBookId(id)==null) {
			throw  new Exceptions("Booking id not found");
		}
		return bookingDao.findByBookId(id);
	}


	public List<Room> searchByRoomType(String type) {
		// TODO Auto-generated method stub
		
		if(bookingDao.findByRoomType(type)==null)
		{
			throw  new Exceptions("Room type  not found");
		}
		return bookingDao.findByRoomType(type);

	}

}
