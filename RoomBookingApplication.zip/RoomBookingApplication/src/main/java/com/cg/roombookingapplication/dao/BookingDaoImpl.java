package com.cg.roombookingapplication.dao;
import com.cg.roombookingapplication.dto.Booking;
import com.cg.roombookingapplication.exception.Exceptions;
import com.cg.roombookingapplication.util.BookingDBUtil;

public class BookingDaoImpl implements IBookingDao {
	public Booking save(Booking booking) {
		BookingDBUtil.bookList.add(booking);
		return booking;
	}
	public Booking findByBookId(int id) throws Exceptions {
		for (Booking booking : BookingDBUtil.bookList) {
			if (booking.getId()==id) {
				return booking;
			}else {
				throw new Exceptions("Booking id not found Exception");
			}
		}
		return null;
	}
}


