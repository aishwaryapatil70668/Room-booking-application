package com.cg.roombookingapplication.exception;



public class NameException {

	public void nameValidate(String name)
	{
		if (!name.matches("[a-zA-Z_]+"))
		  
		{
			throw new  Exceptions("Invalid name");
		}
	
		
	}
}
