package com.cg.roombookingapplication.dao;
import com.cg.roombookingapplication.dto.Booking;

public interface IBookingDao {
	public Booking save(Booking booking); 
	public Booking findByBookId(int id);
}
