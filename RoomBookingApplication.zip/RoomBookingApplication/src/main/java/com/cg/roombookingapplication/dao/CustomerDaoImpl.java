package com.cg.roombookingapplication.dao;
import com.cg.roombookingapplication.dto.Customer;
import com.cg.roombookingapplication.util.CustomerDBUtil;

public class CustomerDaoImpl implements  ICustomerDao{
	
	public Customer save(Customer customer) {
	CustomerDBUtil.customers.add(customer);
		return customer;
	}
}
