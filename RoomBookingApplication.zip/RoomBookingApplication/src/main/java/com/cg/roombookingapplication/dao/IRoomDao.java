package com.cg.roombookingapplication.dao;


import java.util.List;

import com.cg.roombookingapplication.dto.Room;

public interface IRoomDao {

	
	public Room save(Room room);
	 List <Room> findByRoomType(String Type);
}
