package com.cg.roombookingapplication.service;
import java.util.List;
import com.cg.roombookingapplication.dao.IRoomDao;
import com.cg.roombookingapplication.dao.RoomDaoImpl;
import com.cg.roombookingapplication.dto.Room;

public class RoomServiceImpl implements  IRoomService {
	IRoomDao roomDao;
	public RoomServiceImpl() {
		roomDao=new RoomDaoImpl();
	}
	public List<Room> searchByRoomType(String type) {
	
			return roomDao.findByRoomType(type);
	}
	public Room addRoom(Room room) {
		return roomDao.save(room);
	}

}
