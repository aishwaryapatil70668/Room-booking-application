package com.cg.roombookingapplication.service;

import com.cg.roombookingapplication.dao.BookingDaoImpl;
import com.cg.roombookingapplication.dao.IBookingDao;
import com.cg.roombookingapplication.dto.Booking;

public class BookingServiceImpl implements IBookingService {
	IBookingDao bookingDao;	
	public BookingServiceImpl() {
		bookingDao =new BookingDaoImpl();
	}
	public Booking addBooking(Booking booking) {
		return bookingDao.save(booking);
	}
	public Booking searchByBookId(int id) {
		return bookingDao.findByBookId(id);
	}

}
