package com.cg.roombookingapplication.service;

import com.cg.roombookingapplication.dto.Booking;

public interface IBookingService {
	public Booking addBooking(Booking booking);
	public Booking searchByBookId(int id);
}
