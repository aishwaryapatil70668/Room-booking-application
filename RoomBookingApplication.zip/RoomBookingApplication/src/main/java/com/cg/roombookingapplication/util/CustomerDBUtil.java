package com.cg.roombookingapplication.util;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.roombookingapplication.dto.Customer;
public class CustomerDBUtil {
	public static List<Customer> customers=new ArrayList<Customer>();
}
