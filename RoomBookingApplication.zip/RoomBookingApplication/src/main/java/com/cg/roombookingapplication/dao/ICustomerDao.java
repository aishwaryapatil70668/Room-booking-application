package com.cg.roombookingapplication.dao;
import com.cg.roombookingapplication.dto.Customer;

public interface ICustomerDao {
public Customer save(Customer customer);
}
