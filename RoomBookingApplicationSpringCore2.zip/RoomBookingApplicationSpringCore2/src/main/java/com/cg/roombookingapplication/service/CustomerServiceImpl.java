package com.cg.roombookingapplication.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.roombookingapplication.dao.CustomerDaoImpl;
import com.cg.roombookingapplication.dao.ICustomerDao;
import com.cg.roombookingapplication.dto.Customer;
import com.cg.roombookingapplication.exception.Exceptions;


/*
 * @Author Aishwarya patil
 * @Last Modified on 10-05-2019
 * The Following  service class is for Business logic
 */ 
@Service("customerService")
public class CustomerServiceImpl implements ICustomerService {
	
	@Autowired
	ICustomerDao customerDao;
	
	/** 
	 * This method is used to save the customer. 
	 * @param customer this parameter is used to save the customers by given customer
	 * */ 
	public Customer addCustomer(Customer customer) {
		return customerDao.save(customer);
	}
	
	
	/** 
	 * This method is used to search the customer . 
	 * @param id this parameter is used to find the customer by given id
	 * */ 
	public Customer searchByBookId(int id) {
		// TODO Auto-generated method stub
		
		Customer cust=customerDao.findByCustomerId(id);
		if(cust==null)
		throw new Exceptions("Customer id not found Exception");
		return cust;
	}
}
