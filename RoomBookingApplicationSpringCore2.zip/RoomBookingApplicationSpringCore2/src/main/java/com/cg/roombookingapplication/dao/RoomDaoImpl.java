package com.cg.roombookingapplication.dao;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.roombookingapplication.dto.Customer;
import com.cg.roombookingapplication.dto.Room;
import com.cg.roombookingapplication.exception.Exceptions;
import com.cg.roombookingapplication.util.CustomerDBUtil;
import com.cg.roombookingapplication.util.RoomDBUtil;

/*
 * @Author Aishwarya patil
 * @Last Modified on 10-05-2019
 * The Following  Repository class is for database operations
 */ 

@Repository("roomDao")
public class RoomDaoImpl implements IRoomDao {
	
	/** 
	 * This method is used to search the roomtype. 
	 * @param type this parameter is used to find the room type by given type
	 * */ 
	public List<Room> findByRoomType(String Type) {
		
		List<Room> typeSearch=new ArrayList<Room>();
		
		for (Room roomType : RoomDBUtil.roomList)
		{
			if (roomType.getType().equalsIgnoreCase(Type)) {
				typeSearch.add(roomType);
				
				
			}
		}
			
		return typeSearch;
	}
	/** 
	 * This method is used to save the room. 
	 * @param room this parameter is used to save the room by given room
	 * */ 
	public Room save(Room room) {
		RoomDBUtil.roomList.add(room);
		return room;
	}

	public Room findByRoomId(int id) {
		
		// TODO Auto-generated method stub
		for (Room room : RoomDBUtil.roomList) {
			if (room.getId()==id) 
				return room;
		}	
		
	return null;
}
}