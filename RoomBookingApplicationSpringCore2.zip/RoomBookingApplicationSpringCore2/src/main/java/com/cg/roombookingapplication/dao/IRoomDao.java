package com.cg.roombookingapplication.dao;


import java.util.List;

import com.cg.roombookingapplication.dto.Customer;
import com.cg.roombookingapplication.dto.Room;

public interface IRoomDao {

	
	public Room save(Room room);
	public Room findByRoomId(int id);
	 List <Room> findByRoomType(String Type);
}
