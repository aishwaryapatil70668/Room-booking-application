package com.cg.roombookingapplication.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/*
 *This class is responsible for creating beans of all the classes under given package.
 *@Author Aishwarya Patil 
 * 
 */

@Configuration
@ComponentScan("com.cg.roombookingapplication.*")  
public class JavaConfig {

}
