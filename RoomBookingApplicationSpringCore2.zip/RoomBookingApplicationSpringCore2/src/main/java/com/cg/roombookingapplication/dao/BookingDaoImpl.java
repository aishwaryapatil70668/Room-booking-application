package com.cg.roombookingapplication.dao;
import org.springframework.stereotype.Repository;

import com.cg.roombookingapplication.dto.Booking;
import com.cg.roombookingapplication.exception.Exceptions;
import com.cg.roombookingapplication.util.BookingDBUtil;


/*
 * @Author Aishwarya patil
 * @Last Modified on 10-05-2019
 * The Following  Repository class is for database operations
 */ 
@Repository("bookingDao")
public class BookingDaoImpl implements IBookingDao {
	
	/** 
	 * This method is used to save the booking. 
	 * @param booking this parameter is used to save the booking by given booking
	 * */ 
	public Booking save(Booking booking) {
		BookingDBUtil.bookList.add(booking);
		return booking;
	}
	
	

	/** 
	 * This method is used to search the booking . 
	 * @param id this parameter is used to find the booking by given id
	 * */ 
	
	public Booking findByBookId(int id) throws Exceptions {
		for (Booking booking : BookingDBUtil.bookList) 
		{
			if (booking.getId()==id) 
				return booking;			
		}
		
		return null;
	}

}
