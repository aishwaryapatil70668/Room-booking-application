package com.cg.roombookingapplication.main;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;
import com.cg.roombookingapplication.config.JavaConfig;
import com.cg.roombookingapplication.dto.Booking;
import com.cg.roombookingapplication.dto.Customer;
import com.cg.roombookingapplication.dto.Room;
import com.cg.roombookingapplication.exception.Exceptions;
import com.cg.roombookingapplication.service.BookingServiceImpl;
import com.cg.roombookingapplication.service.CustomerServiceImpl;
import com.cg.roombookingapplication.service.IBookingService;
import com.cg.roombookingapplication.service.ICustomerService;
import com.cg.roombookingapplication.service.IRoomService;
import com.cg.roombookingapplication.service.RoomServiceImpl;
import com.cg.roombookingapplication.util.RoomDBUtil;

/*
 * 
 * @Class MyApplication 
 * @Author Aishwarya patil
 * @version 1.0 
 * @Last Modified on 10-05-2019
 * This is the main class which makes use of all functionality
 */ 

@Component
public class MyApplication {
	@Autowired
	ICustomerService customerService;
	@Autowired
	IBookingService bookingService;
	@Autowired
	IRoomService roomService;
		
	
	static ICustomerService customerServiceStat;
	static IBookingService bookingServiceStat;
	static IRoomService roomServiceStat;
	@PostConstruct
	public void init()
	{
		customerServiceStat= this.customerService;
		roomServiceStat=this.roomService;
		bookingServiceStat= this.bookingService;

	}
	public static void main(String[] args) {
		
		ApplicationContext app =  new AnnotationConfigApplicationContext(JavaConfig.class);
		Customer customer=null;
		Booking book=null;
		Room room=null;
		Customer cust=null;
		Room rooms=null;
		int ans;
		Scanner sc=new Scanner(System.in);
		int ch;
		do {	
			printCustomer();
			System.out.println("Enter the choice");
			ch=sc.nextInt();
		switch(ch) {	
		case 1:
			/*
			 * 
			 * @Last Modified on 10-05-2019
			 * The Following case is for Adding customer into collection
			 *@return the customer
			 */ 
		System.out.println("Enter Customer details");
		System.out.println("Enter Customer id");
		int idone=sc.nextInt();
		System.out.println("Enter customer name");
		String name=sc.next();
	
		System.out.println("Enter Mobile number");
		BigInteger mobile=sc.nextBigInteger();
		
	
		System.out.println("Enter Email");
		String email=sc.next();
		System.out.println("Enter address");
		String address =sc.next();
		
		
		customer=(Customer) app.getBean("customer");
		customer.setId(idone);
		customer.setName(name);
		customer.setMobileNo(mobile);
		customer.setEmail(email);
		customer.setAddress(address);
		
		//customer=new Customer(idone,name, mobile,email,address);
		customerServiceStat.addCustomer(customer);
	
		break;
		case 2:
			/*
			 * @Last Modified on 10-05-2019
			 * The Following method is for Adding Rooms into collection
			 * @return the rooms
			 */ 
			
			System.out.print("Add rooms to Book you want:\n");
		 	System.out.println("Enter room details");
		 	System.out.println("Enter room id");
			int idr=sc.nextInt();
		 	System.out.println("Enter room no");
			int no=sc.nextInt();
			System.out.println("Enter room type( Ac/NonAc )");
			String type=sc.next();
			System.out.println("Enter Price");
			BigDecimal price=sc.nextBigDecimal();
			room=(Room) app.getBean("room");
			room.setId(idr);
			room.setNumber(no);
			room.setType(type);
			room.setPrice(price);
	   //     room=new Room(no,type,price);
	        roomServiceStat.addRoom(room);
			break;
		case 3:	
			
			/*
			 * @Last Modified on 10-05-2019
			 * The Following method is for make booking into collection
			 * @return the customer
			 */ 
			book= (Booking) app.getBean("booking");
			System.out.println("Enter customer id");
			int idcust=sc.nextInt();
			try
			{
			 cust=customerServiceStat.searchByBookId(idcust);
			}catch (Exceptions e) {
				System.out.println(e.getMessage());
			}
			
			List<Room> roomslist= new ArrayList<Room>();  
			
			
			
			do {
			System.out.println("Enter room id");
			int idroom=sc.nextInt();
			try
			{
				
			rooms= roomServiceStat.searchByRoomId(idroom);
			roomslist.add(rooms);
			System.out.println(rooms);
			}catch (Exceptions e) {
				System.out.println(e.getMessage());
				
			}
			System.out.println("press 1 to continue /2 to exit");
			ans=sc.nextInt();
			}while(ans!=2);
			
			 System.out.println("Enter Booking details");	
				System.out.println("Enter booking id");
				int id=sc.nextInt();
				System.out.println("Enter Date");
			
				 long millis=System.currentTimeMillis();  
			     java.sql.Date date=new java.sql.Date(millis);  
			     System.out.println(date);  
				System.out.println("Enter totalamount ");
				BigDecimal amount=sc.nextBigDecimal();
				
			
				 book.setId(id);
				 book.setDate(date);
				 book.setTotalAmount(amount);
				 book.setCustomer(cust);
				 book.setRoom(roomslist);
				
				bookingServiceStat.addBooking(book);
				break;		
	
		   
			
		case 4:
			System.out.println("enter the Booking id");
			
			int bid=sc.nextInt();
			try
			{
			Booking bookingSearchid =bookingServiceStat.searchByBookId(bid);
			System.out.println(bookingSearchid);
			}catch(Exceptions e)
			{	System.out.println(e.getMessage()+"\n");
			 break;
			}	
			break;
			
		case 5:
			System.out.println("enter Room type (AC/NonAC) ");
			String rtype=sc.next();
		
			try
			{
			List<Room> roomsType =roomServiceStat.searchByRoomType(rtype);
			
			for(Room roomAll: roomsType)
			{	System.out.println("Room no: "+roomAll.getNumber());
				System.out.println("Type is: "+roomAll.getType());
				System.out.println("Price is: "+roomAll.getPrice()+"\n");
			}
			}catch(Exceptions e) {
				System.out.println(e.getMessage()+"\n");
				 break;
			}
			break;
			}
		}while(ch<6);	
	}
	private static void printCustomer() {
		System.out.println("1.Add Customer");
		System.out.println("2.Add Room");
		System.out.println("3.Add Booking");
		System.out.println("4.search by Id");
		System.out.println("5.search by Room Type (AC/NonAC)\n");	
	}	
}
/*
List<Customer> customerList=customerService.showall();
for(Customer customerData: customerList)
		{	System.out.println("customer name is = "+customerData.getName());
			System.out.println("mobile number is = "+customerData.getMobileNo());
			System.out.println("email is = "+customerData.getEmail());
			System.out.println("address is = "+customerData.getAddress());
		}
break;
*/
//System.out.println("Enter room no");int rNo=sc.nextInt(); if(room.getNo()==rNo)room.setNo(rNo);