package com.cg.roombookingapplication.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.roombookingapplication.dao.BookingDaoImpl;
import com.cg.roombookingapplication.dao.IBookingDao;
import com.cg.roombookingapplication.dto.Booking;
import com.cg.roombookingapplication.exception.Exceptions;

/*
 * @Author Aishwarya patil
 * @Last Modified on 10-05-2019
 * The Following service class is for Business logic
 */ 

@Service("bookingService")
public class BookingServiceImpl implements IBookingService {
	
	
	@Autowired
	IBookingDao bookingDao;	
	
	/** 
	 * This method is used to save the booking. 
	 * @param booking this parameter is used to save the booking by given booking
	 * */ 
	public Booking addBooking(Booking booking) {
		
		return bookingDao.save(booking);
	}
	
	/** 
	 * This method is used to search the booking . 
	 * @param id this parameter is used to find the booking by given id
	 * */ 
	public Booking searchByBookId(int id) {
		
		Booking book=bookingDao.findByBookId(id);
		if(book==null)
		throw new Exceptions("Booking id not found ");
		
		return book;
	}

}
