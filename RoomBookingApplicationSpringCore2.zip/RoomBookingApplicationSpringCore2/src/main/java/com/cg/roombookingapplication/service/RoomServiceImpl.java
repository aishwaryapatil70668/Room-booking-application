package com.cg.roombookingapplication.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.roombookingapplication.dao.IRoomDao;
import com.cg.roombookingapplication.dao.RoomDaoImpl;
import com.cg.roombookingapplication.dto.Room;
import com.cg.roombookingapplication.exception.Exceptions;

/*
 * @Author Aishwarya patil
 * @Last Modified on 10-05-2019
 * The Following  service class is for Business logic
 */ 
@Service("roomService")
public class RoomServiceImpl implements  IRoomService {
	
	@Autowired
	IRoomDao roomDao;
	
	/** 
	 * This method is used to search the roomtype. 
	 * @param type this parameter is used to find the room type by given type
	 * */ 
	public List<Room> searchByRoomType(String type) {
	
		List<Room> room=roomDao.findByRoomType(type);
		if(room.isEmpty())
			throw new Exceptions("this type of room not found ");
			return room;	
	}
	
	
	/** 
	 * This method is used to save the room. 
	 * @param room this parameter is used to save the room by given room
	 * */ 
	public Room addRoom(Room room) {
		return roomDao.save(room);
	}
	
	public Room searchByRoomId(int id) {
		// TODO Auto-generated method stub
		Room room=roomDao.findByRoomId(id);
		if(room==null)
			throw new Exceptions("Room id not found Exception");
		return room;
	}

}
