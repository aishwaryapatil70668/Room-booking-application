package com.cg.roombookingapplication.service;

import java.util.List;

import com.cg.roombookingapplication.dto.Customer;
import com.cg.roombookingapplication.dto.Room;

public interface IRoomService {

		public Room addRoom(Room room);
		public Room searchByRoomId(int id);
		List<Room> searchByRoomType(String type);
}
