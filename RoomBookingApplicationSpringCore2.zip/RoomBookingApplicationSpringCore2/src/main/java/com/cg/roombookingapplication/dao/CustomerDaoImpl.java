package com.cg.roombookingapplication.dao;
import org.springframework.stereotype.Repository;

import com.cg.roombookingapplication.dto.Booking;
import com.cg.roombookingapplication.dto.Customer;
import com.cg.roombookingapplication.exception.Exceptions;
import com.cg.roombookingapplication.util.BookingDBUtil;
import com.cg.roombookingapplication.util.CustomerDBUtil;

/*
 * @Author Aishwarya patil
 * @Last Modified on 10-05-2019
 * The Following  Repository class is for database operations
 */ 
@Repository("customerDao")
public class CustomerDaoImpl implements  ICustomerDao{

		/** 
		 * This method is used to save the customer. 
		 * @param customer this parameter is used to save the customers by given customer
		 * */ 
	 public Customer save(Customer customer) {
	CustomerDBUtil.customers.add(customer);
		return customer;
	}
	
	
	/** 
	 * This method is used to search the customer . 
	 * @param id this parameter is used to find the customer by given id
	 * */ 
	public Customer findByCustomerId(int id) {

		for (Customer customer : CustomerDBUtil.customers) {
			if (customer.getId()==id) {
				return customer;
			}
				
		}
		return null;
	}
}
