package com.cg.booking.dao;


import java.util.List;

import com.cg.booking.dto.Room;



public interface IRoomDao {

	
	public Room save(Room room);
	 List <Room> findByRoomType(String Type);
}
