
package com.cg.booking.dao;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.booking.dto.Booking;
import com.cg.booking.dto.Customer;
import com.cg.booking.dto.Room;
import com.cg.booking.exception.Exceptions;
import com.cg.booking.util.ConnectionDBUtil;


public class BookingDaoImpl implements IBookingDao {
	public Booking save(Booking booking) {
		 {
				Connection con=ConnectionDBUtil.getConnection();
				String query1="INSERT INTO BOOKING VALUE(?,?,?,?)";
				PreparedStatement pst=null;
				PreparedStatement pstone=null;
				PreparedStatement psttwo=null;
				try {		
				
					String query2="SELECT CUSTOMERID FROM booking WHERE CUSTOMERID=?";
					pstone=con.prepareStatement(query2);
					pstone.setInt(1, booking.getCustomer().getId() );
					ResultSet rs=pstone.executeQuery();
				  
					if(rs.next()==false)
				    {
				    
				    	/*if(booking.getCustomer().getId()!=rs.getInt(1))
				    	{*/
				    		pst=con.prepareStatement(query1);
							pst.setInt(1, booking.getId());
							pst.setDate(2, booking.getDate());
							pst.setBigDecimal(3, booking.getTotalAmount());
							pst.setInt(4, booking.getCustomer().getId());
							pst.executeUpdate();
							
							String queryTwo="UPDATE ROOM SET BOOKINGID=? WHERE BOOKINGID IS NULL";
							psttwo=con.prepareStatement(queryTwo);
							psttwo.setInt(1, booking.getId());
							System.out.println(booking.getId());
							psttwo.executeUpdate();
							
				    	}else
				    	{
				    		
				    		throw new Exceptions("you have enterd the duplicate ID");
				    		
				    	}
				    
				    	
				    }
				    	 catch (SQLException e) {
				    		 throw new Exceptions("you have enterd the duplicate ID");
					
				}
				
				return null;
		 }
	}
	
	
	
	public Booking findByBookId(int id) throws Exceptions {
	Connection con=ConnectionDBUtil.getConnection();
		String query_insert="SELECT B.BookingId,B.Date,B.Amount, C.CustomerID , C.Name ,C.Email, C.MobileNumber ,C.Address, R.RoomNumber,R.RoomType,R.RoomPrice FROM BOOKING AS B INNER JOIN CUSTOMER AS C ON B.CUSTOMERID =C.CUSTOMERID INNER JOIN ROOM AS R ON B.BOOKINGID=R.BOOKINGID WHERE B.BOOKINGID=?";
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		Booking book = new Booking();
		Customer custone= new Customer();
		List<Room> roomlist = new ArrayList<Room>();
		try{
			pstmt = con.prepareStatement(query_insert);
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();	
			while(rs.next())	{
			book.setId(rs.getInt(1));
			book.setDate(rs.getDate(2));
			book.setTotalAmount(rs.getBigDecimal(3));
			custone.setId(rs.getInt(4));
			custone.setName(rs.getString(5));
			custone.setEmail(rs.getString(6));
			custone.setMobileNo(new BigInteger(rs.getString(7)));
			custone.setAddress(rs.getString(8));
			book.setCustomer(custone);
	
			Room rooms= new Room();
			rooms.setNumber(rs.getInt(9));
			rooms.setType(rs.getString(10));
			rooms.setPrice(rs.getBigDecimal(11));
			roomlist.add(rooms);
		
			book.setRoom(roomlist);		
		}	
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		finally
 		{
	try
	{		
	pstmt.close();	
	
	}catch(SQLException e)
	{
		throw new Exceptions("connection not closed");	
	}
}
		return book;

	}
}

