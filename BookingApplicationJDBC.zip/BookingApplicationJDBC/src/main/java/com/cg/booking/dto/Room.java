package com.cg.booking.dto;


import java.math.BigDecimal;

public class Room {

	private int number;
	private String type;
	private BigDecimal price;
	
	public Room() {
		
	}
	public Room(int number, String type, BigDecimal price) {
		super();
		this.number = number;
		this.type = type;
		this.price = price;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	
	
	@Override
	public String toString() {
		return "[number=" + number + ", type=" + type + ", price=" + price + "]";
	}
	
	
	
	
}