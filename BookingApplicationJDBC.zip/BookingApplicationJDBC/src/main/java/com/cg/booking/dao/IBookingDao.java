package com.cg.booking.dao;

import com.cg.booking.dto.Booking;

public interface IBookingDao {
	public Booking save(Booking booking); 
	public Booking findByBookId(int id);
}
