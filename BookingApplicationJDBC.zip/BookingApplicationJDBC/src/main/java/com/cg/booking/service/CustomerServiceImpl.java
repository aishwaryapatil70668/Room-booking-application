package com.cg.booking.service;

import com.cg.booking.dao.CustomerDaoImpl;
import com.cg.booking.dao.ICustomerDao;
import com.cg.booking.dto.Customer;


public class CustomerServiceImpl implements ICustomerService {
	ICustomerDao customerDao;
	public CustomerServiceImpl() {
		customerDao =new CustomerDaoImpl();
}
	public Customer addCustomer(Customer customer) {
		return customerDao.save(customer);
	}
	public Customer searchByCustomerId(int id) {
		// TODO Auto-generated method stub
		return customerDao.findById(id);
	}
	
}
