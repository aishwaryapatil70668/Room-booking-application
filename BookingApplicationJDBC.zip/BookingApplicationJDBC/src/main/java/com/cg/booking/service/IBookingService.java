package com.cg.booking.service;

import com.cg.booking.dto.Booking;

public interface IBookingService {
	public Booking addBooking(Booking booking);
	public Booking searchByBookId(int id);
}
