package com.cg.booking.dao;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.booking.dto.Customer;
import com.cg.booking.exception.Exceptions;
import com.cg.booking.util.ConnectionDBUtil;

public class CustomerDaoImpl implements  ICustomerDao{


	public Customer save(Customer customer) {
		Connection con=ConnectionDBUtil.getConnection();
		String query1="INSERT INTO CUSTOMER VALUE(?,?,?,?,?)";
		PreparedStatement pst=null;
		try {
			
			pst=con.prepareStatement(query1);
			pst.setInt(1, customer.getId());
			pst.setString(2, customer.getName());
			pst.setString(3, customer.getEmail());
			pst.setString(4, customer.getMobileNumber().toString());
			pst.setString(5, customer.getAddress());
		
			pst.executeUpdate();
		} catch (SQLException e) {

			throw new Exceptions("Insertion fails");
			
		}finally
		{
			try
			{
				
			pst.close();	
				
			}catch(SQLException e)
			{
				throw new Exceptions("connection not closed");
				
			}	
			
			
		}
		
		return null;
	
	}
		
	
	public Customer findById(int id) {
		Connection con = ConnectionDBUtil.getConnection();
		String query_insert="SELECT * FROM customer WHERE CustomerID=?";
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		Customer cust= new Customer();
		try{
			pstmt = con.prepareStatement(query_insert);
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			rs.next();
			cust.setId(rs.getInt(1));
			cust.setName(rs.getString(1));
			cust.setEmail(rs.getString(3));
			cust.setMobileNo(new BigInteger(rs.getString(4)));
			cust.setAddress(rs.getString(5));
		
			
		}catch(SQLException e) {
		
			throw new Exceptions("id is already exist");
			
		}finally
		{
			try
			{		
			pstmt.close();	
				
			}catch(SQLException e)
			{
				throw new Exceptions("connection not closed");	
			}
		}
		return cust;
	
	}
	
}
