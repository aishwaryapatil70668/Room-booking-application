package com.cg.booking.exception;

public class Exceptions extends RuntimeException{
	public  Exceptions() {
	}
	public Exceptions(String msg) {
		super(msg);
	}
}
