package com.cg.booking.service;

import com.cg.booking.dao.BookingDaoImpl;
import com.cg.booking.dao.IBookingDao;
import com.cg.booking.dto.Booking;
import com.cg.booking.exception.Exceptions;


public class BookingServiceImpl implements IBookingService {
	IBookingDao bookingDao;	
	public BookingServiceImpl() {
		bookingDao =new BookingDaoImpl();
	}
	
	
	public Booking addBooking(Booking booking) {
		
		
		
		return bookingDao.save(booking);
	}
	
	// This method is used to find Booking details of customer
	// id is the parameter to search book id method 
	public Booking searchByBookId(int id) {
		Booking book=bookingDao.findByBookId(id);
		if(book.getId()!=id)
			throw new Exceptions("Booking id not found");
		return bookingDao.findByBookId(id);
	}

}
