package com.cg.roombookingapplication.config;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;


/*This is ApplicationInitializer class extends AbstractAnnotationConfigDispatcherServletInitializer class .
 * 
 * @author Aishwarya Patil
 * Last Modified 21-05-2019 11.58 a.m
 * 
 * */ 
public class ApplicationInitilizer  extends AbstractAnnotationConfigDispatcherServletInitializer{

	@Override
	protected Class<?>[] getRootConfigClasses() {
		// TODO Auto-generated method stub
		return new Class[] {AppContext.class};
	}

	@Override
	protected Class<?>[] getServletConfigClasses() {
		// TODO Auto-generated method stub
		return new Class[] {WebMvc.class};
	}

	@Override
	protected String[] getServletMappings() {
		// TODO Auto-generated method stub
		return new String[] {"/"};
	}

}
