package com.cg.roombookingapplication.dto;

import java.math.BigInteger;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import java.math.BigInteger;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/*
 * This is bean class for customer it includes Integer id, String name,BigInteger mobile number,String email, String address
 * Constructor,getter setter ,toString is defined
 *  Last Modified 14/05/2019  
 *  @Author: Aishwarya Patil
 * */  

@Entity
public class Customer {
	@Id
	@Column(name="customerid")
	private Integer id;
	private String name;
	private BigInteger mobileNumber;
	private String email;
	private String address;
	
	public Customer() {
	
	}
	

	public Customer(Integer id, String name, BigInteger mobileNumber, String email, String address) {
		super();
		this.id = id;
		this.name = name;
		this.mobileNumber = mobileNumber;
		this.email = email;
		this.address = address;
	}



	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public BigInteger getMobileNumber() {
		return mobileNumber;
	}


	public void setMobileNumber(BigInteger mobileNumber) {
		this.mobileNumber = mobileNumber;
	}


	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return " [Customer id=" + id + ", name=" + name + ", mobileNumber=" + mobileNumber + ", email=" + email
				+ ", address=" + address + "]";
	}
	

}
