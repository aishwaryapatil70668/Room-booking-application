package com.cg.roombookingapplication.dto;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

/*
 * This is bean class for booking it includes Integer id, TimeStamp date ,BigDecimal totalAmount, Customer customer,List<Room> rooms
 * Constructor,getter setter ,toString is defined
 *  Last Modified 14/05/2019  
 *  @Author: Aishwarya Patil
 * */  

@Entity
public class Booking {
	@Id
	@Column(name="bookingid")
	private Integer id;
	private Timestamp date;
	private BigDecimal totalAmount;
	
	@OneToOne
	private Customer customer;
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="book_room")
	private List<Room> rooms = new ArrayList<Room>();
	
	public Booking() {
	
	}
	


	public Booking(Integer id, Timestamp date, BigDecimal totalAmount, Customer customer, List<Room> rooms) {
		super();
		this.id = id;
		this.date = date;
		this.totalAmount = totalAmount;
		this.customer = customer;
		this.rooms = rooms;
	}


	public Integer getId() {
		return id;
	}



	public void setId(Integer id) {
		this.id = id;
	}



	public Timestamp getDate() {
		return date;
	}



	public void setDate(Timestamp date) {
		this.date = date;
	}



	public List<Room> getRooms() {
		return rooms;
	}



	public void setRooms(List<Room> rooms) {
		this.rooms = rooms;
	}



	public BigDecimal getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<Room> getRoom() {
		return rooms;
	}

	public void setRoom(List<Room> rooms) {
		this.rooms = rooms;
	}



	@Override
	public String toString() {
		return "Booking [id=" + id + ", date=" + date + ", totalAmount=" + totalAmount + ", customer=" + customer
				+ ", rooms=" + rooms + "]";
	}



	/*@Override
	public String toString() {
		return "Booking [id=" + id + ", date=" + date + ", totalAmount=" + totalAmount + ", customer=" + customer
				+ ", rooms=" + rooms + "]";
	}*/

	/*@Override
	public String toString() {
		return "Booking details \n[Bookingid =" + id + ", date=" + date + ", totalAmount=" + totalAmount + ",Customer Details=" + customer
				+ ",Rooms Details =" + rooms + "]";
	}*/

	
	
	


}
