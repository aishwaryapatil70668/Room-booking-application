package com.cg.roombookingapplication.service;

import java.util.List;

import com.cg.roombookingapplication.dto.Booking;
import com.cg.roombookingapplication.dto.Room;

public interface IBookingService {
	public Booking addBooking(Booking booking);
	public Booking searchByBookId(int id);
	List<Room> searchByRoomType(String type);
}
