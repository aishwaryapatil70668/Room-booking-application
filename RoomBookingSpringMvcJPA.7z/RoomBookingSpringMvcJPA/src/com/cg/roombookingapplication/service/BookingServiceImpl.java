package com.cg.roombookingapplication.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.roombookingapplication.dao.BookingDaoImpl;
import com.cg.roombookingapplication.dao.IBookingDao;
import com.cg.roombookingapplication.dto.Booking;
import com.cg.roombookingapplication.dto.Room;
import com.cg.roombookingapplication.exception.Exceptions;

/*
 * @Author Aishwarya patil
 * @Last Modified on 10-05-2019
 * The Following service class is for Business logic
 */ 

@Service("bookingService")
@Transactional
public class BookingServiceImpl implements IBookingService {
	
	
	@Autowired
	IBookingDao bookingDao;	
	static int roomid=1; 
	
	
	/** 
	 * This method is used to save the booking. 
	 * @param booking this parameter is used to save the booking by given booking
	 * */ 
	public Booking addBooking(Booking booking) {
		
		for(Room room:booking.getRooms())
		{
			room.setId(roomid);
			roomid++;
		}
		return bookingDao.save(booking);
	}
	
	/** 
	 * This method is used to search the booking . 
	 * @param id this parameter is used to find the booking by given id
	 * */ 
	public Booking searchByBookId(int id) {
		
		Booking book=bookingDao.findByBookId(id);
		if(book==null)
		throw new Exceptions("Booking id not found ");
		
		return book;
	}
	
	
	/** 
	 * This method is used to search the roomtype. 
	 * @param type this parameter is used to find the room type by given type
	 * */ 
	public List<Room> searchByRoomType(String type) {
		
		List<Room> room=bookingDao.findByRoomType(type);
		if(room.isEmpty())
			throw new Exceptions("this type of room not found ");
		
			return room;	
	}
	
	

}
