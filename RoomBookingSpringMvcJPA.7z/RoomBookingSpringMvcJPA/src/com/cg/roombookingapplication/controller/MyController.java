package com.cg.roombookingapplication.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;



import com.cg.roombookingapplication.dto.Booking;
import com.cg.roombookingapplication.dto.Customer;
import com.cg.roombookingapplication.dto.Room;
import com.cg.roombookingapplication.exception.CustomerException;
import com.cg.roombookingapplication.exception.CustomerIdException;
import com.cg.roombookingapplication.exception.Exceptions;
import com.cg.roombookingapplication.service.IBookingService;
import com.cg.roombookingapplication.service.ICustomerService;

@Controller
public class MyController {
     
	@Autowired
	ICustomerService custservice;

	@Autowired
	IBookingService bookservice; 
	

	Room rooms=null;
	Customer customer=null;
	Booking books=null;
	
	@GetMapping("login")
	public String loginPage() {
		return "listpage";

	}

	@GetMapping("addcust")
	public ModelAndView getAddCustomer(@ModelAttribute("cust") Customer customer) {
		return new ModelAndView("addcustomer");
	}

	@PostMapping("addcustomer")
	public ModelAndView addTrainee(@ModelAttribute("cust") Customer cust) {
	 customer = custservice.addCustomer(cust);
		return new ModelAndView("addcustomer", "custkey", customer);
		//return new ModelAndView("listpage");
	}
	

	
	@GetMapping("searchlist")
	public ModelAndView search() {
		return new ModelAndView("searchtype");
	}

	
	@PostMapping("searchtype")
	public ModelAndView getSearchTrainee(@RequestParam("type") String type,Model m) {
		List<Room> roomlist=bookservice.searchByRoomType(type);
		m.addAttribute("room",roomlist);
		return new ModelAndView("searchtype");
		
	}
	
	
	
	
	@GetMapping("searchbyid")
	public ModelAndView searchid() {
		return new ModelAndView("searchid");
	}

	
	@PostMapping("searchid")
	public ModelAndView getSearchid(@RequestParam("id") int id,Model m) {
		Booking book=bookservice.searchByBookId(id);
		m.addAttribute("bookkey",book);
		return new ModelAndView("roomsuccess");
		
	}
	
	
	
	
	
	@GetMapping("addbook")
	public ModelAndView getAddbook(@ModelAttribute("book") Booking book) {
		return new ModelAndView("makebooking");
	}

	@PostMapping("makebooking")
	public ModelAndView addBooking(@ModelAttribute("book") Booking book ) {
		
		
		this.books=book;
			return new ModelAndView("addRooms");
	}
	
	
	 @PostMapping("addRooms")
	 public ModelAndView addtran(/*@RequestParam("id") int id*/@RequestParam("number")  int number,@RequestParam("type") String type,@RequestParam("price") BigDecimal price) {
//		 System.out.println(pro);
	
		 Room rooms= new Room();
	//	 rooms.setId(id);
		 rooms.setPrice(price);
		 rooms.setNumber(number);
		 rooms.setType(type);
		 
		 List<Room> list=new ArrayList<Room>();
		 list.add(rooms);
		 
		 Booking book=new Booking();
		 book.setId(books.getId());
		 book.setCustomer(books.getCustomer());
		 book.setDate(books.getDate());
		 book.setTotalAmount(books.getTotalAmount());
		 book.setRoom(list);
	
		 Booking booking=bookservice.addBooking(book);
		 
		
		 return new  ModelAndView("addRooms","key",booking);
		 //return new  ModelAndView("addRooms");
	 }

	 
	 
	
		 @ExceptionHandler({Exceptions.class})
		 public ModelAndView handlePlayerException( Exceptions e) {

		 	ModelAndView model = new ModelAndView("error");

		 	model.addObject("err", e.getMessage());

		 	return model;

		 }  
		 

		 @ExceptionHandler({CustomerException.class})
		 public ModelAndView handlePlayerExceptionS( CustomerException e) {

		 	ModelAndView model = new ModelAndView("error");

		 	model.addObject("err1", e.getMessage());

		 	return model;

		 }  
		  
		 @ExceptionHandler({CustomerIdException.class})
		 public ModelAndView handlePlayerExceptionCust( CustomerIdException e) {

		 	ModelAndView model = new ModelAndView("error");

		 	model.addObject("err2", e.getMessage());

		 	return model;

		 }  
		  
	 
	
	
	 /* @PostMapping("addroom")
	 public ModelAndView addtran(@ModelAttribute("book") Booking bookings) {
//		 System.out.println(pro);
	
		 Room rooms= new Room();
		 rooms.setId(rooms.getId());
		 rooms.setNumber(rooms.getNumber());
		 rooms.setPrice(rooms.getPrice());
		 rooms.setType(rooms.getType());
		 
		 rooms.setBook(bookings);
		 List<Room> list=new ArrayList<Room>();
		 list.add(rooms);
		 
		 Booking book=new Booking();
		 bookings.setId(books.getId());
		 bookings.setCustomer(books.getCustomer());
		 bookings.setDate(books.getDate());
		 bookings.setTotalAmount(books.getTotalAmount());
		 bookings.setRoom(list);
	
		 Booking booking=bookservice.addBooking(bookings);
		 
		
		 return new  ModelAndView("booksuccess","key",booking);
	 }
*/
	
	
	
}