package com.cg.roombookingapplication.exception;

public class CustomerException extends RuntimeException {

	public CustomerException()
	{
		
	}
	public CustomerException(String msgs)
	{
		super(msgs);
	}
	
}
