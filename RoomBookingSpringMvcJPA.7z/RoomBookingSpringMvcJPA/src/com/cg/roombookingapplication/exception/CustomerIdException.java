package com.cg.roombookingapplication.exception;

public class CustomerIdException extends RuntimeException {

	public CustomerIdException()
	{
		
	}
	public CustomerIdException(String msgs)
	{
		super(msgs);
	}
}
