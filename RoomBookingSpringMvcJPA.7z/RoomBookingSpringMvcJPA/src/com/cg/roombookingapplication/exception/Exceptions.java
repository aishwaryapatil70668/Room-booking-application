package com.cg.roombookingapplication.exception;

public class Exceptions extends RuntimeException{
	public  Exceptions() {
	}
	public Exceptions(String msg) {
		super(msg);
	}
}
