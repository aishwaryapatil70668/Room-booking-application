package com.cg.roombookingapplication.dao;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.stereotype.Repository;
import com.cg.roombookingapplication.dto.Booking;
import com.cg.roombookingapplication.dto.Customer;
import com.cg.roombookingapplication.dto.Room;
import com.cg.roombookingapplication.exception.CustomerIdException;
import com.cg.roombookingapplication.exception.Exceptions;


/*
 * @Author Aishwarya patil
 * @Last Modified on 10-05-2019
 * The Following  Repository class is for database operations
 */ 
@Repository("bookingDao")
public class BookingDaoImpl implements IBookingDao {
	
	
	@PersistenceContext
	EntityManager em;

		static final Logger logger = Logger.getLogger(BookingDaoImpl.class); 
		 

	
	/** 
	 * This method is used to save the booking. 
	 * @param booking this parameter is used to save the booking by given booking
	 * */ 
	public Booking save(Booking booking) {
	
PropertyConfigurator.configure("D:\\JavaProjectadvance\\RoomBookingSpringMvcJPA\\src\\resources\\log4j.properties"); 
			 

		
		Customer cust=em.find(Customer.class, booking.getCustomer().getId());
		if(cust==null)
		{	
			logger.info("customer id not found");
			throw new CustomerIdException("Customer id not found" );
		}

		else {		
		Booking book=findByBookId(booking.getId());

		
		
		if(book==null) {
	
		em.persist(booking);
		em.flush();
		}
		else
		{
		      	
	
			Room rooms= new Room();
			rooms.setBook(booking);
			rooms.setId(booking.getRoom().get(0).getId());
			rooms.setPrice(booking.getRoom().get(0).getPrice());
			rooms.setNumber(booking.getRoom().get(0).getNumber());
			rooms.setType(booking.getRoom().get(0).getType());
		
			em.persist(rooms);
			em.flush();
			
			
		}
		}
		return booking;	 

	}
	

	/** 
	 * This method is used to search the booking . 
	 * @param id this parameter is used to find the booking by given id
	 * */ 
	
	public Booking findByBookId(int id) throws Exceptions {
	
		
		
		
		PropertyConfigurator.configure("D:\\JavaProjectadvance\\RoomBookingSpringMvcJPA\\src\\resources\\log4j.properties"); 
		
		
		
		
		
		Booking book=null;
		try {
			
		Query query=em.createQuery("from Booking where id=:bookId");
		query.setParameter("bookId", id);
		
		book=(Booking) query.getSingleResult();
		}catch (NoResultException e) {
			
			
			System.out.println("booking id not found");
		}
		logger.info("searching booking details by id");
		return book;
		
	}
	
	
	/** 
	 * This method is used to search the roomtype. 
	 * @param type this parameter is used to find the room type by given type
	 * */ 
	public List<Room> findByRoomType(String Type) {

		PropertyConfigurator.configure("D:\\JavaProjectadvance\\RoomBookingSpringMvcJPA\\src\\resources\\log4j.properties"); 
		Query query = em.createQuery("FROM Room r where r.type = :type ");
		query.setParameter("type", Type);
		List<Room> roomtype = query.getResultList();
		logger.info("searching room by type");
		return roomtype;
	}

}
