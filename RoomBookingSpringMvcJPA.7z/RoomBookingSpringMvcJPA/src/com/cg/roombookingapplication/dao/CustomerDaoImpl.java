package com.cg.roombookingapplication.dao;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.stereotype.Repository;


import com.cg.roombookingapplication.dto.Booking;
import com.cg.roombookingapplication.dto.Customer;
import com.cg.roombookingapplication.exception.CustomerException;
import com.cg.roombookingapplication.exception.Exceptions;


/*
 * @Author Aishwarya patil
 * @Last Modified on 10-05-2019
 * The Following  Repository class is for database operations
 */ 
@Repository("customerDao")
public class CustomerDaoImpl implements  ICustomerDao{
	@PersistenceContext
	EntityManager em;
	static final Logger logger = Logger.getLogger(CustomerDaoImpl.class); 	
	/** 
		 * This method is used to save the customer. 
		 * @param customer this parameter is used to save the customers by given customer
		 * */

	public Customer save(Customer customer) {
		PropertyConfigurator.configure("D:\\JavaProjectadvance\\RoomBookingSpringMvcJPA\\src\\resources\\log4j.properties"); 
		
		Customer cust=findByCustomerId(customer.getId());
		if(cust==null) 
		{
		em.persist(customer);
		em.flush();
		}
		else
		{	logger.info("customer id already exist");
			
		
		throw new CustomerException("id already exist");
		}
		logger.info("customer added successful");
		return customer;
		
		
	}

	/** 
	 * This method is used to search the customer . 
	 * @param id this parameter is used to find the customer by given id
	 * */ 
	public Customer findByCustomerId(int id) {
		PropertyConfigurator.configure("D:\\JavaProjectadvance\\RoomBookingSpringMvcJPA\\src\\resources\\log4j.properties"); 
		logger.info("searching customer by id");
	return em.find(Customer.class,id);
	}
}
