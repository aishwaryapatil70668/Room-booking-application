package com.cg.roombookingapplication.dao;
import java.util.List;

import com.cg.roombookingapplication.dto.Booking;
import com.cg.roombookingapplication.dto.Room;

public interface IBookingDao {
	public Booking save(Booking booking); 
	public Booking findByBookId(int id);
	 List <Room> findByRoomType(String Type);
}
